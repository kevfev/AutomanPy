import core.automanlib as pyAutomanlib
from core.grpc_gen_classes.automanlib_rpc_pb2 import TaskResponse
from core.grpc_gen_classes.automanlib_classes_pb2 import SymmetricConInt, AsymmetricConInt, UnconstrainedConInt, Task
from core.pyautomanexceptions import ArgumentError, UnsupportedServerError, AdapterError
from time import sleep
import sys
import grpc


class ConfidenceInterval():
	"""
	An interface for a confidence interval
	"""
	def makeCI(self,):
		pass

	def addCI(self,task):
		pass

class UnconstrainedCI(ConfidenceInterval):
	"""
	A Symmetric confidence interval
	Attributes
    ----------
    error : float
    	The desired confidence interval
	"""
	def makeCI(self):
		return UnconstrainedConInt()

	def addCI(self,task):
		return task.withUnconstrainedConInt()


class SymmetricCI(ConfidenceInterval):
	"""
	A Symmetric confidence interval
	Attributes
	----------
	error : float
		The desired confidence interval
	"""
	def __init__(self, error):
		self.error = error

	def makeCI(self):
		return SymmetricConInt(err=self.error)

	def addCI(self,task):
		return task.withSymmetricConInt(self)



class AsymmetricCI(ConfidenceInterval):
	"""
	A Symmetric confidence interval
	Attributes
	----------
	error : float
		The desired confidence interval
	"""
	def __init__(self, low_error, high_error):
		self.low_error = low_error
		self.high_error = high_error

	def makeCI():
		return SymmetricConInt(low_err = self.low_error, high_err = self.high_error)

	def addCI(self,task):
		return task.UnconstrainedConInt()

class EstimateOutcome():
	"""
	The Outcome Class. This class holds the result of an Automan computation

	Attributes
	----------
	_future_task_resp : TaskResponse
		A private variable, stores the future representing the response from the server for the estimation task. 
		The future will be resolved by calling isConfident, isLowConfidence, or isOverBudget.
	_evaluated : boolean
		A private variable indicating whether the object's stored future has been resolved (True) or not (False)
	_outcome_type_val : str
		A private variable that holds the type of outcome, can be "CONFIDENT", "LOW_CONFIDENCE", and "OVERBUDGET"
	low : float
		The lowest valued worker response. Only set if the outcome is "CONFIDENT" or "LOW_CONFIDENCE"
	est : float
		The estimated value. Only set if the outcome is "CONFIDENT" or "LOW_CONFIDENCE"
	high : float
		The highest valued worker response. Only set if the outcome is "CONFIDENT" or "LOW_CONFIDENCE"
	cost : float
		The cost of the task. Only set if the outcome is "CONFIDENT" or "LOW_CONFIDENCE"
	conf : float
		The confidence of the estimate. Only set if the outcome is "CONFIDENT" or "LOW_CONFIDENCE"
	need : float
		The amount needed to retry posting the task. Only set if the outcome is "OVERBUDGET"
	have : float
		The amount previously budget. Only set if the outcome is "OVERBUDGET"
	"""

	def __init__(self, future_tr):
		"""
		Ensure necessary fields in adapter are initializated and
		set up the gRPC channel

		Parameters
		----------
		future_tr : TaskResponse
			A future representing the response from the server for the estimation task. The future will be resolved
			by calling isConfident, isLowConfidence, or isOverBudget.
		"""
		self._future_task_resp = future_tr
		self._evaluated = False
		self._outcome_type_val = None
		self.low = float('nan')
		self.high = float('nan')
		self.est = float('nan')
		self.cost = float('nan')
		self.conf = float('nan')
		self.need = float('nan')
		self.have = float('nan')


		self.types_outcome = {'CONFIDENT':1, 'LOW_CONFIDENCE':2, 'OVERBUDGET':3}

	def _resolveResponse(self,response):
		"""
		Internal method.  Evaluate the response from the gRPC server. First determine if response is valid.
		The field return_code can take the following values:
			TaskResponse.VALID 
			TaskResponse.ERROR
			TaskResponse.EXCEPTION

		Parameters
		----------
		response : TaskResponse
			The response from the server

		Returns
		-------
		TaskOutcome
			If the response is valid, it returns the outcome of the task. If there was an error or exception, 
			returned by the server the function terminates the script and prints an error message to output

		"""
		ret_string = None
		if response.return_code == TaskResponse.VALID:
			return response.estimate_outcome
		if response.return_code == TaskResponse.UNDEFINED_RESP_CODE:
			ret_string= "ERROR: An undefind response code was returned. Application may be out of data or there is an error on the grpc server side"
		if response.return_code == TaskResponse.ERROR:
			ret_string = "ERROR: An error occured \n"+ "Message: "+response.err_msg
		if response.return_code == TaskResponse.EXCEPTION:
			ret_string ="EXCEPTION: An exception occured \n"+ "Message: "+response.excep_msg

		sys.exit(ret_string)

	def _evalOutcome(self, waitTime = None):
		"""
		Evaluates the result of the outcome from the future task response and initializes the correct fields of 
		the EstimateOutcome returned to the user. This method will block.

		Raises
		------
		TimeoutError: 	If a timeout value is passed and the computation does not
						terminate within the allotted time.

		CancelledError: If the computation was cancelled.

		Exception: 		If the computation raised an exception, this call will raise
						the same exception.
		"""
		try:
			future = self._future_task_resp.result(timeout = waitTime)
		except TimeoutError:
			print("TimeoutError: This outcome timed out before its future resolved.")
			raise
		except CancelledError:
			print("CancelledError: This gRPC call has been cancelled")
			raise
		except Exception: 
			raise

		outcome = self._resolveResponse(future)
		if self.types_outcome['OVERBUDGET'] ==  outcome.outcome_type:
			self.need= outcome.need
			self.have = outcome.have
			self._outcome_type_val = "OVERBUDGET"
		else:
			self.low = outcome.answer.low
			self.high = outcome.answer.high
			self.est = outcome.answer.est
			self.conf = outcome.answer.conf
			self.cost = outcome.answer.cost
			if self.types_outcome['CONFIDENT'] ==  outcome.outcome_type:
				self._outcome_type_val = "CONFIDENT"
			if self.types_outcome['LOW_CONFIDENCE'] ==  outcome.outcome_type:
				self._outcome_type_val = "LOW_CONFIDENCE"
		self._evaluated = True

	def outcomeType(self):
		"""
		Returns the string outcome type
		Returns
		-------
		String
			The outcome type. One of: CONFIDENT, LOW_CONFIDENCE or OVERBUDGET

		"""
		return self._outcome_type_val

	def done(self, timeout = None):
		"""
		waits for the future to resolve,blocks

		"""
		self._evalOutcome(waitTime = timeout)

	def isDone(self):
		"""
		Returns a boolean indicating whether the outcome's future is resolved or not as yet
		Returns
		-------
		boolean
			True if the outcome's future is resolved, False otherwise. Does not block.

		"""
		return self._evaluated

	def printOutcome(self, timeout = None):
		if(self.isConfident(timeout)):
			print("Outcome: Estimate")
			print("Estimate low: %f high:%f est:%f "%(self.low, self.high, self.est))


		if(self.isLowConfidence(timeout)):
			print("Outcome: Low Confidence Estimate")
			print("Estimate low: %f high:%f est:%f "%(self.low, self.high, self.est))

		if(self.isOverBudget(timeout)):
			print("Outcome: Over Budget")
			print(" need: %f have:%f"%(self.need, self.have))

	def isConfident(self, timeout = None):
		"""
		Evaluates the outcome (if it is not already evaluated) and determines whether the outcome
		type was a confident estimate. This call will block if the future is not yet resolved.

		Returns
		-------
		bool
			True if outcome is an estimate
			False otherwise
		"""
		
		if not self._evaluated:
			self._evalOutcome(waitTime = timeout)
		return 'ESTIMATE' == self._outcome_type_val

	def isLowConfidence(self, timeout = None):
		"""
		Evaluates the outcome (if it is not already evaluated) and determines whether the outcome
		type was a low confidence estimate. This call will block if the future is not yet resolved.

		Returns
		-------
		bool
			True if outcome is a low confidence estimate
			False otherwise
		"""
		if not self._evaluated:
			self._evalOutcome(waitTime = timeout)
		return 'LOW_CONFIDENCE' == self._outcome_type_val

	def isOverBudget(self, timeout = None):
		"""
		Evaluates the outcome (if it is not already evaluated) and determines whether the outcome
		type overbudget. This call will block if the future is not yet resolved.

		Returns
		-------
		bool
			True if outcome is over budget
			False otherwise
		"""
		if not self._evaluated:
			self._evalOutcome(waitTime = timeout)
		return 'OVERBUDGET' == self._outcome_type_val

class Automan():
	"""
	The Automan Class.

	Attributes
	----------
	lglvl : int
		An integer representing the desired log verbosity for the AutoMan worker
	srvr_addr : str
		The hostname for the gRPC server
	port : int 
		The port to connect to on the hostname 
	channel: Channel
		The gRPC channel to communicate over
	srvr_popen_obj : Popen 
		The Popen object returned when the RPC AutoMan scala server is started
	supr_lvl : string 
		Specifies how much of the output to suppress from the RPC server
	"""

	#dicts declared here are used internally for convenience to map user supplied strings to integers
	LogLevels = {
		'debug' : 0,
		'info' : 1,
		'warn' : 2,
		'fatal' : 3
	}

	Logging = {
		'tm' : 0,
		'none' : 1,
		't' : 2,
		'tv' : 3,
		'tvm' : 4
	}

	def __init__(self, adapter, server_addr = 'localhost', port = 50051, suppress_output = 'all', 
					loglevel = 'fatal', logging='none', stdout =None, stderr = None):
		"""
		Ensure necessary fields in adapter are initializated and
		set up the gRPC channel

		Parameters
		----------
		adapter : dict
			A dictionary containing the parameters for the adapter
		server_addr : str
			The hostname for the gRPC server
		port : int 
			The port to connect to on the hostname 
		suppress_output : string
			Specifies how much of the output to suppress from the RPC server. Values are:
				all 	- suppress all output from rpc server
				stdout 	- suppress all output from rpc server
				file 	- redirect output from rpc server to files specified by 
							stdout and stderr 
				none 	- suppress no output from rpc server
		loglevel : string
			Specifies the AutoMan worker log level, for setting the level of output from AutoMan. values
				'debug' - debug level 
				'info' 	- information level (default)
				'warn' 	- warnings only
				'fatal' - fatal messages only
		logging : string
			Specifies the log configuration of the AutoMan worker. Values are 
				'none' 	- no logging 
				't' 	- log trace only
				'tm' 	- log trace and use for memoization
				'tv' 	- log trace and output debug information
				'tmv' 	- log trace, use for memoization and output debug infor
		[NOT YET IMPLEMENTED]
		stdout : string
			File path to write RPC server standard output to
		stderr : string
			File path to write RPC server error output to
		
		Raises
		------
		AdapterError: Indicates there was an error creating the adapter, see msg field of exception for more info
		ArgumentError: Indicates there was an error with one of the supplied arguments
		UnsupportedServerError: Currently, only local servers (server_addr ='localhost') is supported, this is thrown 
								the user intends to create a server that is not on localhost

		"""

		# type checking, basic error checking
		if not isinstance(adapter, dict): raise ArgumentError("adapter must be of type dict")
		if not isinstance(server_addr, str) or not server_addr.strip(): raise ArgumentError("server_addr must be of type str (only 'localhost' supported), cannot be empty")
		if not isinstance(port, int) or port<=0: raise ArgumentError("port must be of type int, must be greater than 0")
		if not isinstance(suppress_output, str) or not suppress_output.strip(): raise ArgumentError("suppress_output must be of type str, cannot be empty")
		if not isinstance(loglevel, str) or not loglevel.strip(): raise ArgumentError("loglevel must be of type str, cannot be empty")
		if not isinstance(logging, str) or not logging.strip(): raise ArgumentError("logging must be of type str, cannot be empty")

		# these checks will become relevant when file logging is in place
		#if stdout and not isinstance(stdout, str): raise ArgumentError("stdout must be of type str (desired path to file)")
		#if stderr and not isinstance(stderr, str): raise ArgumentError("stderr must be of type str (desired path to file)")

		# this is only temporary
		if server_addr.lower() != "localhost":
			print server_addr.lower()
			raise UnsupportedServerError()

		self.lglvl = Automan.LogLevels.get(loglevel.lower(), Automan.LogLevels['fatal'])
		self.lg =  Automan.Logging.get(logging.lower(), Automan.Logging['tm'])
		self.srvr_addr = server_addr
		self.port = port
		self.srvr_popen_obj = None
		self.supr_lvl = suppress_output
		self.stdout_file = stdout
		self.stderr_file = stderr
		self.channel = None

		try:
			_adptr = pyAutomanlib.make_adapter(adapter, self.lglvl, self.lg) 
		except AdapterError:
			raise
		self.adptr = _adptr

		# set up channel, start and connect to gRPC server
		self._init_channel(server_addr, port)
		self._start()
		self._register_adptr()

	def _start(self, sleep_time = 5):
		"""
		Private method, used to start the gRPC AutoMan server. If a server address is set to 'localhost', the client
		will attempt to start a server listening on the specified port (default 55051). If a server is already started on
		this port, the client will send requests. If a server is not started, the client will start one.

		"""
		try:
			resp = pyAutomanlib.get_server_status(self.channel)
		except grpc.RpcError as rpc_err:
			if rpc_err.code() == grpc.StatusCode.UNAVAILABLE:
				self.srvr_popen_obj = pyAutomanlib.start_rpc_server(port=self.port, suppress_output = self.supr_lvl,
					stdout_file = self.stdout_file, stderr_file = self.stderr_file)
				sleep(sleep_time)
			else:
				sys.exit("Unable to start server, "+rpc_err.details())
	
	def _register_adptr(self):
		"""
		Private method, used to register an adapter with the server

		"""
		# handle response
		resp = pyAutomanlib.register_adapter_to_server(self.channel, self.adptr)

	def _shutdown(self):
		"""
		Private method. Shutdown the gRPC server

		"""
		# handle response
		resp = pyAutomanlib.shutdown_rpc_server(self.channel)

	def _force_shutdown(self):
		"""
		Private method. Forces shutdown the gRPC server by killing spawned process

		"""
		self.srvr_popen_obj.kill()


	def _init_channel(self, server_addr, port):
		"""
		Private method. Create the gRPC channel

		Parameters
		----------
		server_addr : str
			The hostname for the gRPC server
		port : int 
			The port to connect to on the hostname 

		Returns
		-------
		Channel
			A channel that connects to the gRPC back-end server

		"""
		self.channel = pyAutomanlib.make_channel(server_addr,str(port))
		 

	def estimate(self, text, budget, image_url="", title = "", confidence = 0.95, confidence_int = -1, img_alt_txt = "",sample_size = -1, dont_reject = True, 
				pay_all_on_failure = True, dry_run = False, wage = 11.00, max_value = sys.float_info.max, min_value = sys.float_info.min, question_timeout_multiplier = 500, 
				initial_worker_timeout_in_s = 30):
		"""
		Estimates the answer to the provided task. Calls AutoMan's estimate functionality on the back-end

		Parameters
		----------
		title : str
			The title for the task, to display to workers on the crowdsource platform
		text : str
			The text description of the task, to display to workers on the crowdsource platform
		image_url : str
			The url of the image for the task
		budget : float
			The total budget allocated for this task
		confidence : float
			The desired confidence level 
		confidence_int : float
			The desired confidence interval. If '-1', an Unconstrained Confidence Internal is used,
			if set to a value, a symmetric confidence interval of with confidence_int is used.
		img_alt_txt : str
			The alternate image text to display on the webpage
		sample_size : int
			The desired sample size 
		dont_reject : boolean
			?
		pay_all_on_failure : boolean
			? 
		dry_run : boolean
			? 
		wage : float
			Minimum wage to pay the worker
		max_value : float
			?
		min_value : float
			?
		question_timeout_multiplier: float
			?
		initial_worker_timeout_in_s : int
			?

		Returns
		-------
		EstimateOutcome
			A wrapper class that contains a future estimation outcome.
		Raises
		------
		ArgumentError: Indicates there was an error with one of the supplied arguments
		"""
		# type checking and basic error checking
		if not isinstance(text, str) or not text.strip(): raise ArgumentError("text must be of type str, cannot be empty")
		if not isinstance(img_alt_txt, str): raise ArgumentError("img_alt_txt must be of type str")
		if not isinstance(title, str): raise ArgumentError("title must be of type str")
		if not isinstance(image_url, str): raise ArgumentError("image_url must be of type str")
		if not isinstance(budget, (int, float)) or budget <= 0: raise ArgumentError("budget must be of type float, must be strictly greater than 0")
		if not isinstance(confidence, (int, float)) or confidence <= 0: raise ArgumentError("confidence must be of type float, must be strictly greater than 0")
		if not isinstance(wage, (int, float)) or wage <= 0: raise ArgumentError("wage must be of type float, must be strictly greater than 0")
		if not isinstance(max_value, (int, float)): raise ArgumentError("max_value must be of type float, must be strictly greater than 0")
		if not isinstance(min_value, (int, float)): raise ArgumentError("min_value must be of type float, must be strictly greater than 0")
		if not isinstance(question_timeout_multiplier, int) or question_timeout_multiplier <= 0: raise ArgumentError("question_timeout_multiplier must be of type int, must be strictly greater than 0")
		if not isinstance(initial_worker_timeout_in_s, int) or initial_worker_timeout_in_s <= 0: raise ArgumentError("initial_worker_timeout_in_s must be of type int, must be strictly greater than 0")
		if not isinstance(dont_reject, bool): raise ArgumentError("dont_reject must be of type bool")
		if not isinstance(pay_all_on_failure, bool): raise ArgumentError("pay_all_on_failure must be of type bool")
		if not isinstance(dry_run, bool): raise ArgumentError("dry_run must be of type bool")

		# check these values if they are not default
		if confidence_int != -1:
			if not isinstance(confidence_int, (int, float)) or confidence_int <= 0: raise ArgumentError("confidence_int must be of type float, must be strictly greater than 0")
		if sample_size != -1:
			if not isinstance(sample_size, int) or sample_size <= 0: raise ArgumentError("sample_size must be of type int, must be strictly greater than 0")

		task = pyAutomanlib.make_est_task(text_ = text,
										budget_ = float(budget),
										title_ = title,
										image_url_ = image_url,
										confidence_ = float(confidence),
										confidence_int_ = float(confidence_int),
										img_alt_txt_ = img_alt_txt,
										sample_size_ = sample_size, 
										dont_reject_ = dont_reject, 
										pay_all_on_failure_ = pay_all_on_failure, 
										dry_run_ = dry_run, 
										wage_ = float(wage),
										max_value_ = float(max_value),
										min_value_ = float(min_value),
										question_timeout_multiplier_ = question_timeout_multiplier,
										initial_worker_timeout_in_s_ = initial_worker_timeout_in_s)
		resp = pyAutomanlib.submit_task(self.channel, task, self.adptr)
		eo = EstimateOutcome(future_tr=resp)
		return eo
